package com.gomovie.dao.impl;

import java.util.ArrayList;
import java.util.List;

public class test {

	public static void main(String[] args) {
		// TODO Aulocation1.add("����");
		List<String> location1 = new ArrayList<String>();
		location1.add("3����");
		
	    int a = location1.size();
	    System.out.println("aaaaaaaaaaaaaaaaaaa = location1.size()==============="+a);

	}

}
