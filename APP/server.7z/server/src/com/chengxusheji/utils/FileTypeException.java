package com.chengxusheji.utils;
public class FileTypeException extends Exception {

	public FileTypeException(String msg){  
	    super(msg);  
	 }  
	 
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	
	
}
